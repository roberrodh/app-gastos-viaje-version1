package com.example.tripmanager.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.tripmanager.data.Expense
import com.example.tripmanager.data.AppDatabase
import kotlinx.coroutines.launch

class ExpenseViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val expenseDao = db.expenseDao()

    // Función para añadir un gasto
    fun addExpense(amount: Double, description: String) {
        viewModelScope.launch {
            val expense = Expense(amount = amount, description = description, tripId = 1) // tripId está hardcodeado por ahora
            expenseDao.insertExpense(expense)
        }
    }

    // Función para borrar un gasto
    fun deleteExpense(expense: Expense) {
        viewModelScope.launch {
            expenseDao.delete(expense)
        }
    }

    // Función para obtener todos los gastos
    fun getAllExpenses() = expenseDao.getAllExpenses()


}
