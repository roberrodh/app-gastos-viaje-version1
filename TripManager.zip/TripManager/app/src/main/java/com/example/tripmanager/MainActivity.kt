package com.example.tripmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.platform.LocalContext
import com.example.tripmanager.viewmodel.ExpenseViewModel
import com.example.tripmanager.data.Expense
import kotlinx.coroutines.flow.collect

class MainActivity : ComponentActivity() {
    private val expenseViewModel: ExpenseViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AddExpenseScreen(expenseViewModel)
        }
    }
}

@Composable
fun AddExpenseScreen(expenseViewModel: ExpenseViewModel) {
    var amount by remember { mutableStateOf(TextFieldValue("")) }
    var description by remember { mutableStateOf(TextFieldValue("")) }
    var expenses by remember { mutableStateOf(listOf<Expense>()) }
    var showError by remember { mutableStateOf(false) }

    // Función para añadir el gasto
    fun addExpense() {
        val amountValue = amount.text.toDoubleOrNull()
        if (amountValue != null && description.text.isNotBlank()) {
            expenseViewModel.addExpense(amountValue, description.text)
            // Limpiar los campos
            amount = TextFieldValue("")
            description = TextFieldValue("")
            showError = false
        } else {
            showError = true // Mostrar el error si los datos no son válidos
        }
    }

    // Función para eliminar un gasto
    fun deleteExpense(expense: Expense) {
        expenseViewModel.deleteExpense(expense)
    }

    // Recoger la lista de gastos
    LaunchedEffect(Unit) {
        expenseViewModel.getAllExpenses().collect { list ->
            expenses = list
        }
    }

    // Calcular el total de los gastos
    val totalAmount = expenses.sumOf { it.amount }

    Column(modifier = Modifier.padding(16.dp)) {
        // Entrada para el monto
        TextField(
            value = amount,
            onValueChange = { amount = it },
            label = { Text("Cantidad") },
            keyboardOptions = KeyboardOptions.Default.copy(
                keyboardType = KeyboardType.Number
            ),
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
        )

        // Entrada para la descripción
        TextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("Descripción") },
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
        )

        // Botón para añadir el gasto
        Button(
            onClick = { addExpense() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Añadir Gasto")
        }

        // Mostrar lista de gastos añadidos con LazyColumn para el scroll
        Spacer(modifier = Modifier.height(16.dp))
        LazyColumn(modifier = Modifier.fillMaxWidth()) {
            items(expenses) { expense -> // Asegúrate de usar 'items(expenses)' correctamente aquí
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Mostrar los detalles de cada gasto
                    Text(text = "Cantidad: ${expense.amount}, Descripción: ${expense.description}")

                    // Icono de eliminar para cada gasto
                    IconButton(onClick = { deleteExpense(expense) }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Eliminar Gasto")
                    }
                }
            }
        }

        // Mostrar el total de los gastos
        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "Total: €${"%.2f".format(totalAmount)}", style = MaterialTheme.typography.bodyLarge)

        // Mostrar mensaje de error si los campos son incorrectos
        if (showError) {
            Snackbar(modifier = Modifier.padding(top = 16.dp)) {
                Text("Por favor, ingrese una cantidad y descripción válidas.")
            }
        }
    }
}
